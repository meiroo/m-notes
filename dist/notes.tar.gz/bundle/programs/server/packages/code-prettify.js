(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['code-prettify'] = {};

})();

//# sourceMappingURL=code-prettify.js.map
