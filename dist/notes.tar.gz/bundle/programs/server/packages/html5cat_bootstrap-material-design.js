(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['html5cat:bootstrap-material-design'] = {};

})();

//# sourceMappingURL=html5cat_bootstrap-material-design.js.map
